<?php
include "conexion.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

$mensaje = "";
$editando = false;
$editarDatos = null;

// ===========================================
// 1) REGISTRAR NUEVA TOMA + NUEVO PROPIETARIO
// ===========================================
if (isset($_POST["registrar"])) {

    $nombre = $conexion->real_escape_string($_POST["nombre"]);
    $telefono = $conexion->real_escape_string($_POST["telefono"]);
    $direccion = $conexion->real_escape_string($_POST["direccion"]);
    $numero_toma = $conexion->real_escape_string($_POST["numero_toma"]);
    $id_tarifa = intval($_POST["id_tarifa"]);

    // Verificar si la toma ya existe
    $existe = $conexion->query("SELECT * FROM tomas WHERE numero_toma='$numero_toma'");
    if ($existe->num_rows > 0) {
        $mensaje = "❗ El número de toma ya existe.";
    } else {

        // Registrar nuevo propietario
        $conexion->query("
            INSERT INTO usuarios (nombre, telefono, direccion, rol)
            VALUES ('$nombre', '$telefono', '$direccion', 'PROPIETARIO')
        ");

        $id_usuario = $conexion->insert_id;

        // Registrar toma
        $conexion->query("
            INSERT INTO tomas (numero_toma, id_usuario, id_tarifa, estado)
            VALUES ('$numero_toma', $id_usuario, $id_tarifa, 'ACTIVA')
        ");

        header("Location: admin_tomas.php?msg=registrado");
        exit;
    }
}

// ==========================
// 2) CARGAR TOMA PARA EDITAR
// ==========================
if (isset($_GET["editar"])) {
    $editando = true;
    $idEditar = intval($_GET["editar"]);

    $res = $conexion->query("
        SELECT t.*, u.nombre, u.telefono, u.direccion 
        FROM tomas t
        INNER JOIN usuarios u ON t.id_usuario = u.id_usuario
        WHERE t.id_toma=$idEditar
    ");

    if ($res->num_rows > 0) {
        $editarDatos = $res->fetch_assoc();
    }
}

// ==========================
// 3) GUARDAR CAMBIOS EDITADOS
// ==========================
if (isset($_POST["guardarCambios"])) {

    $id_toma = intval($_POST["id_toma"]);
    $numero_toma = $conexion->real_escape_string($_POST["numero_toma"]);
    $nombre = $conexion->real_escape_string($_POST["nombre"]);
    $telefono = $conexion->real_escape_string($_POST["telefono"]);
    $direccion = $conexion->real_escape_string($_POST["direccion"]);
    $id_tarifa = intval($_POST["id_tarifa"]);
    $estado = $_POST["estado"];
    $id_usuario = intval($_POST["id_usuario"]);

    // Actualizar datos del propietario
    $conexion->query("
        UPDATE usuarios
        SET nombre='$nombre', telefono='$telefono', direccion='$direccion'
        WHERE id_usuario=$id_usuario
    ");

    // Actualizar datos de la toma
    $conexion->query("
        UPDATE tomas
        SET numero_toma='$numero_toma',
            id_tarifa='$id_tarifa',
            estado='$estado'
        WHERE id_toma=$id_toma
    ");

    header("Location: admin_tomas.php?msg=modificado");
    exit;
}

// ==========================
// 4) ACTIVAR / DESACTIVAR
// ==========================
if (isset($_GET["toggle"])) {

    $id = intval($_GET["toggle"]);
    $estadoActual = $conexion->query("SELECT estado FROM tomas WHERE id_toma=$id")->fetch_assoc()["estado"];

    $nuevo = ($estadoActual == "ACTIVA") ? "INACTIVA" : "ACTIVA";

    $conexion->query("UPDATE tomas SET estado='$nuevo' WHERE id_toma=$id");

    header("Location: admin_tomas.php");
    exit;
}

// ==========================
// 5) BUSCAR TOMAS
// ==========================
$where = "";
if (isset($_GET["buscar"]) && $_GET["buscar"] != "") {
    $b = $conexion->real_escape_string($_GET["buscar"]);
    $where = "WHERE numero_toma LIKE '%$b%' OR nombre LIKE '%$b%'";
}

// ==========================
// 6) LISTADO DE TOMAS
// ==========================
$tomas = $conexion->query("
    SELECT t.id_toma, t.numero_toma, t.estado, 
           u.id_usuario, u.nombre, u.telefono, u.direccion,
           tar.id_tarifa, tar.descripcion
    FROM tomas t
    INNER JOIN usuarios u ON t.id_usuario = u.id_usuario
    INNER JOIN tarifas tar ON t.id_tarifa = tar.id_tarifa
    $where
    ORDER BY id_toma DESC
");

$tarifas = $conexion->query("SELECT * FROM tarifas WHERE activa=1 ORDER BY descripcion ASC");

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Administración de Tomas</title>

<style>
body { background:#121212; color:white; font-family:Arial; text-align:center; }
.card { background:#1f1f1f; padding:20px; width:85%; margin:auto; border-radius:10px; }
input, select { padding:10px; width:250px; margin:5px; border-radius:6px; border:none; }
button { padding:10px 25px; background:#ff3b3b; border:none; color:white; border-radius:6px; cursor:pointer; }
table { width:100%; margin-top:20px; border-collapse:collapse; }
th, td { padding:10px; border:1px solid #333; }
th { background:#222; }
.activa { color:#4CAF50; font-weight:bold; }
.inactiva { color:#ff3b3b; font-weight:bold; }
</style>
</head>
<body>

<h1>Administración de Tomas</h1>

<?php if (!empty($mensaje)): ?>
<div class="card" style="color:#ffdd57;"><?= $mensaje ?></div>
<?php endif; ?>

<!-- ===================== -->
<!-- FORMULARIO DE EDICIÓN -->
<!-- ===================== -->
<?php if ($editando): ?>
<div class="card">
    <h2>Modificar Toma</h2>

    <form method="POST">

        <input type="hidden" name="id_toma" value="<?= $editarDatos['id_toma'] ?>">
        <input type="hidden" name="id_usuario" value="<?= $editarDatos['id_usuario'] ?>">

        <input type="text" name="numero_toma" value="<?= $editarDatos['numero_toma'] ?>" required>

        <input type="text" name="nombre" value="<?= $editarDatos['nombre'] ?>" required>
        <input type="text" name="telefono" value="<?= $editarDatos['telefono'] ?>">
        <input type="text" name="direccion" value="<?= $editarDatos['direccion'] ?>" required>

        <select name="id_tarifa" required>
            <?php
            $t2 = $conexion->query("SELECT * FROM tarifas ORDER BY descripcion ASC");
            while ($t = $t2->fetch_assoc()):
            ?>
                <option value="<?= $t['id_tarifa'] ?>"
                    <?= $t['id_tarifa'] == $editarDatos['id_tarifa'] ? 'selected' : '' ?>>
                    <?= $t['descripcion'] ?>
                </option>
            <?php endwhile; ?>
        </select>

        <select name="estado">
            <option value="ACTIVA" <?= $editarDatos['estado']=='ACTIVA'?'selected':'' ?>>ACTIVA</option>
            <option value="INACTIVA" <?= $editarDatos['estado']=='INACTIVA'?'selected':'' ?>>INACTIVA</option>
        </select>

        <br><br>
        <button name="guardarCambios">Guardar Cambios</button>
        <a href="admin_tomas.php" style="margin-left:10px; color:#ff3b3b;">Cancelar</a>
    </form>
</div>
<?php else: ?>

<!-- ========================= -->
<!-- FORMULARIO DE REGISTRO -->
<!-- ========================= -->
<div class="card">
    <h2>Registrar Nueva Toma</h2>

    <form method="POST">

        <h3>Propietario</h3>
        <input type="text" name="nombre" placeholder="Nombre completo" required>
        <input type="text" name="telefono" placeholder="Teléfono">
        <input type="text" name="direccion" placeholder="Dirección" required>

        <h3>Toma</h3>
        <input type="text" name="numero_toma" placeholder="Número de toma" required>

        <select name="id_tarifa" required>
            <option value="">Seleccione tarifa</option>
            <?php while($t = $tarifas->fetch_assoc()): ?>
                <option value="<?= $t['id_tarifa'] ?>"><?= $t['descripcion'] ?></option>
            <?php endwhile; ?>
        </select>

        <br><br>
        <button name="registrar">Registrar</button>
    </form>
</div>

<?php endif; ?>

<!-- ========================= -->
<!-- BUSCAR -->
<!-- ========================= -->
<div class="card">
    <h2>Buscar Toma</h2>
    <form>
        <input type="text" name="buscar" placeholder="Número de toma o propietario">
        <button>Buscar</button>
        <a href="admin_tomas.php" style="margin-left:10px; color:#ff3b3b;">Limpiar</a>
    </form>
</div>

<!-- ========================= -->
<!-- LISTADO DE TOMAS -->
<!-- ========================= -->
<div class="card">
    <h2>Listado de Tomas</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Número</th>
            <th>Propietario</th>
            <th>Tarifa</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>

        <?php while($r = $tomas->fetch_assoc()): ?>
        <tr>
            <td><?= $r['id_toma'] ?></td>
            <td><?= $r['numero_toma'] ?></td>
            <td><?= $r['nombre'] ?></td>
            <td><?= $r['descripcion'] ?></td>
            <td class="<?= strtolower($r['estado']) ?>"><?= $r['estado'] ?></td>

            <td>
                <a href="admin_tomas.php?editar=<?= $r['id_toma'] ?>" style="color:#4aa3ff">Modificar</a> |
                <a href="admin_tomas.php?toggle=<?= $r['id_toma'] ?>" 
                   style="color:<?= $r['estado']=='ACTIVA'?'red':'green' ?>;">
                    <?= $r['estado']=='ACTIVA'?'Deshabilitar':'Activar' ?>
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>