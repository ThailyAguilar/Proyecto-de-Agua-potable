<?php
$servidor = "localhost";
$usuario = "root";
$contrasena = "";
$bd = "sistema_agua";

$conexion = new mysqli($servidor, $usuario, $contrasena, $bd);

if ($conexion->connect_error) {
    die("❌ Error al conectar: " . $conexion->connect_error);
}

$conexion->set_charset("utf8");
?>