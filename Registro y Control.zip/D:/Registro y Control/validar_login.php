<?php
session_start();
include "conexion.php";

$nombre = $_POST['nombre'];
$password = $_POST['password'];

$consulta = "SELECT * FROM usuarios WHERE nombre='$nombre' AND password='$password'";
$resultado = mysqli_query($conexion, $consulta);

if(mysqli_num_rows($resultado) > 0){
    $usuario = mysqli_fetch_assoc($resultado);
    $_SESSION['usuario'] = $usuario['nombre'];
    $_SESSION['rol'] = $usuario['rol'];
    header("Location: lista_usuarios.php");
} else {
    header("Location: login.php?error=1");
}
?>