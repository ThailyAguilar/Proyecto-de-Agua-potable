<?php
session_start();
include 'conexion.php';

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$query = "SELECT * FROM usuarios WHERE nombre='$usuario' AND password='$password'";
$resultado = mysqli_query($conexion, $query);

if(mysqli_num_rows($resultado) > 0){
    $datos = mysqli_fetch_assoc($resultado);
    $_SESSION['usuario'] = $datos['nombre'];
    $_SESSION['rol'] = $datos['rol'];
    header("Location: dashboard.php");
}else{
    echo "<script>alert('Datos incorrectos'); window.location='login.php';</script>";
}
?>