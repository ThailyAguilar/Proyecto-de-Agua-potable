<?php
session_start();
include "conexion.php";

if ($_SESSION['rol'] != 'ADMIN') {
    header("Location: lista_usuarios.php");
    exit();
}

$id = $_POST['id_usuario'];
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$rol = $_POST['rol'];

$update = "UPDATE usuarios SET nombre='$nombre', telefono='$telefono', direccion='$direccion', rol='$rol' WHERE id_usuario=$id";
mysqli_query($conexion, $update);

header("Location: lista_usuarios.php?updated=1");
?>