<?php
session_start();
include "conexion.php";

if ($_SESSION['rol'] != 'ADMIN') {
    header("Location: lista_usuarios.php");
    exit();
}

$id = $_GET['id'];
$consulta = mysqli_query($conexion, "SELECT * FROM usuarios WHERE id_usuario=$id");
$usuario = mysqli_fetch_assoc($consulta);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container col-md-6 mt-5">
    <div class="card shadow">
        <div class="card-header text-center">
            <h4>Editar Usuario</h4>
        </div>
        <div class="card-body">
            <form action="actualizar_usuario.php" method="POST">
                <input type="hidden" name="id_usuario" value="<?= $usuario['id_usuario'] ?>">

                <label class="form-label">Nombre</label>
                <input type="text" name="nombre" class="form-control" value="<?= $usuario['nombre'] ?>" required>

                <label class="form-label mt-3">Teléfono</label>
                <input type="text" name="telefono" class="form-control" value="<?= $usuario['telefono'] ?>">

                <label class="form-label mt-3">Dirección</label>
                <input type="text" name="direccion" class="form-control" value="<?= $usuario['direccion'] ?>">

                <label class="form-label mt-3">Rol</label>
                <select name="rol" class="form-select" required>
                    <option <?= $usuario['rol']=="PROPIETARIO"?"selected":"" ?>>PROPIETARIO</option>
                    <option <?= $usuario['rol']=="COBRADOR"?"selected":"" ?>>COBRADOR</option>
                    <option <?= $usuario['rol']=="ADMIN"?"selected":"" ?>>ADMIN</option>
                </select>

                <button class="btn btn-warning w-100 mt-4">Actualizar Usuario</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>