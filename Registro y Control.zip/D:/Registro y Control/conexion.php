<?php
$conexion = mysqli_connect("localhost", "root", "", "sistema_cobranza");
if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}
?>