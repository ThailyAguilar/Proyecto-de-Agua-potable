<?php
$conexion = mysqli_connect("localhost", "root", "", "sistema_cobranza");
?>