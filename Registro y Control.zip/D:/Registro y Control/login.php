<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
<div class="col-md-4 offset-md-4">
<div class="card p-4 shadow">
<h4 class="text-center">Iniciar Sesión</h4>
<form action="validar_login.php" method="POST">
<label class="form-label">Usuario</label>
<input type="text" name="usuario" class="form-control" required>
<label class="form-label mt-2">Contraseña</label>
<input type="password" name="password" class="form-control" required>
<button type="submit" class="btn btn-primary w-100 mt-3">Ingresar</button>
</form>
</div>
</div>
</div>
</body>
</html>