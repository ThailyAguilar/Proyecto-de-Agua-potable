<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container col-md-4 mt-5">
    <div class="card shadow">
        <div class="card-header text-center">
            <h4>Inicio de Sesión</h4>
        </div>
        <div class="card-body">
            <form action="validar_login.php" method="POST">
                <label class="form-label">Usuario (Nombre)</label>
                <input type="text" name="nombre" class="form-control" required>

                <label class="form-label mt-3">Contraseña</label>
                <input type="password" name="password" class="form-control" required>

                <button class="btn btn-primary w-100 mt-4">Ingresar</button>
            </form>
            <?php if(isset($_GET['error'])) echo '<p class="text-danger mt-3 text-center">Datos incorrectos</p>'; ?>
        </div>
    </div>
</div>
</body>
</html>