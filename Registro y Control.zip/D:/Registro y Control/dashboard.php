<?php
session_start();
if(!isset($_SESSION['usuario'])){ header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark px-3">
<span class="navbar-brand">Panel de Control</span>
<a href="logout.php" class="btn btn-danger">Salir</a>
</nav>

<div class="container mt-4">
<h3>Bienvenido, <?php echo $_SESSION['usuario']; ?></h3>

<?php if($_SESSION['rol'] == 'ADMIN'){ ?>
<a href="registrar_usuario.php" class="btn btn-primary mt-3">Registrar Usuario</a>
<a href="lista_usuarios.php" class="btn btn-secondary mt-3">Ver Usuarios</a>
<?php } ?>

</div>
</body>
</html>