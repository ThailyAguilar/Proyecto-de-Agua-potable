<?php
session_start();
include "conexion.php";

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$consulta = "SELECT * FROM usuarios";
$resultado = mysqli_query($conexion, $consulta);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios Registrados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h3 class="text-center mb-4">Usuarios Registrados</h3>

    <?php if($_SESSION['rol'] == 'ADMIN'): ?>
    <a href="formulario.html" class="btn btn-primary mb-3">Registrar Usuario</a>
    <?php endif; ?>

    <a href="logout.php" class="btn btn-danger mb-3 float-end">Cerrar sesión</a>

    <table class="table table-bordered table-striped shadow">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Rol</th>
                <?php if($_SESSION['rol'] == 'ADMIN'): ?>
                <th>Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php while($fila = mysqli_fetch_assoc($resultado)){ ?>
            <tr>
                <td><?= $fila['id_usuario'] ?></td>
                <td><?= $fila['nombre'] ?></td>
                <td><?= $fila['telefono'] ?></td>
                <td><?= $fila['direccion'] ?></td>
                <td><?= $fila['rol'] ?></td>

                <?php if($_SESSION['rol'] == 'ADMIN'): ?>
                <td>
                    <a href="editar_usuario.php?id=<?= $fila['id_usuario'] ?>" class="btn btn-warning btn-sm">Editar</a>
                    <a href="eliminar_usuario.php?id=<?= $fila['id_usuario'] ?>" class="btn btn-danger btn-sm"
                       onclick="return confirm('¿Seguro que deseas eliminar este usuario?')">Eliminar</a>
                </td>
                <?php endif; ?>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>