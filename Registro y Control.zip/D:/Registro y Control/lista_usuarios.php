<?php
include 'conexion.php';
$resultado = mysqli_query($conexion, "SELECT * FROM usuarios");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<title>Usuarios Registrados</title>
<meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
<h3>Usuarios Registrados</h3>
<table class="table table-bordered table-striped mt-3">
<tr>
<th>ID</th><th>Nombre</th><th>Teléfono</th><th>Dirección</th><th>Rol</th>
</tr>
<?php while($fila = mysqli_fetch_assoc($resultado)){ ?>
<tr>
<td><?php echo $fila['id_usuario']; ?></td>
<td><?php echo $fila['nombre']; ?></td>
<td><?php echo $fila['telefono']; ?></td>
<td><?php echo $fila['direccion']; ?></td>
<td><?php echo $fila['rol']; ?></td>
</tr>
<?php } ?>
</table>
<a href="dashboard.php" class="btn btn-secondary">Volver</a>
</div>
</body>
</html>