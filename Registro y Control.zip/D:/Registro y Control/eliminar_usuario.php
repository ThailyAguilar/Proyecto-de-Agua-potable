<?php
session_start();
include "conexion.php";

if ($_SESSION['rol'] != 'ADMIN') {
    header("Location: lista_usuarios.php");
    exit();
}

$id = $_GET['id'];

mysqli_query($conexion, "DELETE FROM usuarios WHERE id_usuario=$id");

header("Location: lista_usuarios.php?deleted=1");
?>