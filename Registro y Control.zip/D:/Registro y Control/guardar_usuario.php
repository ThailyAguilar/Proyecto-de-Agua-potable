<?php
include 'conexion.php';

$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$rol = $_POST['rol'];
$password = $_POST['password'];

$query = "INSERT INTO usuarios(nombre, telefono, direccion, rol, password) 
VALUES('$nombre', '$telefono', '$direccion', '$rol', '$password')";

mysqli_query($conexion, $query);

header("Location: lista_usuarios.php");
?>