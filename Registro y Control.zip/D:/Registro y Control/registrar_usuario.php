<?php
session_start();
include "conexion.php";

if ($_SESSION['rol'] != 'ADMIN') {
    header("Location: lista_usuarios.php");
    exit();
}

$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$rol = $_POST['rol'];
$password = $_POST['password'];

$insertar = "INSERT INTO usuarios(nombre, telefono, direccion, rol, password) 
VALUES('$nombre', '$telefono', '$direccion', '$rol', '$password')";

mysqli_query($conexion, $insertar);
header("Location: lista_usuarios.php?success=1");
?>